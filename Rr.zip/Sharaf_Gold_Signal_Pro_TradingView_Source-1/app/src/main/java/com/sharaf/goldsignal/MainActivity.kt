package com.sharaf.goldsignal

import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

private val Navy = Color(0xFF10243A)
private val Gold = Color(0xFFE5B84B)
private val Muted = Color(0xFF94A3B8)

// دلته به خپل د Firebase لینک ولیکئ (په پای کې باید /signal.json ولري)
private const val SIGNAL_URL = "https://sharaftgold-default-rtdb.firebaseio.com/signal.json"


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SharafApp() }
    }
}

@Composable
fun SharafApp() {
    var notifications by remember { mutableStateOf(false) }
    var action by remember { mutableStateOf("لا نشته") }
    var entryPrice by remember { mutableStateOf("—") }
    var stopLoss by remember { mutableStateOf("—") }
    var takeProfit by remember { mutableStateOf("—") }
    var statusText by remember { mutableStateOf("له سرور سره نښلول کېږي...") }

    // هر ۵ ثانیې وروسته له سرور څخه نوی سیګنال را اخلي
    LaunchedEffect(Unit) {
        while (true) {
            try {
                val response = withContext(Dispatchers.IO) {
                    URL(SIGNAL_URL).readText()
                }
                if (response != "null" && response.isNotBlank()) {
                    val json = JSONObject(response)
                    action = json.optString("action", "لا نشته")
                    entryPrice = json.optString("entry", "—")
                    stopLoss = json.optString("sl", "—")
                    takeProfit = json.optString("tp", "—")
                    statusText = "ژوندی وصل دی (MT5)"
                }
            } catch (e: Exception) {
                statusText = "انټرنېټ یا سرور وګورئ"
            }
            delay(5000)
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, secondary = Color(0xFF9CC7E8),
        background = Navy, surface = Color(0xFF1A314A)
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = Navy) {
                Column(
                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShowChart, null, tint = Gold, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("SHARAF GOLD", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("سیګنال پرو", color = Color.White)
                        }
                        AssistChip(onClick = {}, label = { Text(statusText, fontSize = 11.sp) })
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A314A))) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("د سرو زرو چارټ", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                            Text("TradingView چارټ • XAUUSD • M15", color = Gold, fontSize = 13.sp)
                            AndroidView(
                                modifier = Modifier.fillMaxWidth().height(390.dp),
                                factory = { context ->
                                    WebView(context).apply {
                                        settings.javaScriptEnabled = true
                                        settings.domStorageEnabled = true
                                        settings.loadWithOverviewMode = true
                                        settings.useWideViewPort = true
                                        webChromeClient = WebChromeClient()
                                        webViewClient = WebViewClient()
                                        loadUrl("file:///android_asset/chart.html")
                                    }
                                }
                            )
                            Text("د چارټ سمبول OANDA:XAUUSD دی؛ دا د Deriv د معاملې بیه نه تضمینوي.",
                                color = Color(0xFFFFD580), fontSize = 12.sp)
                        }
                    }
                    Text("د سیګنال معلومات", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SignalCard("لارښوونه", action, Modifier.weight(1f))
                        SignalCard("د ننوتلو بیه", entryPrice, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SignalCard("د تاوان حد (SL)", stopLoss, Modifier.weight(1f))
                        SignalCard("د ګټې هدف (TP)", takeProfit, Modifier.weight(1f))
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A314A))) {
                        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, null, tint = Gold)
                                Spacer(Modifier.width(8.dp))
                                Text("د خطر مدیریت", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Text("Demo بیلانس: $50", color = Color.White)
                            Text("د هرې معاملې خطر هدف: 0.5% (تر $0.25 پورې)",
                                color = Color(0xFFCBD5E1), fontSize = 13.sp)
                            Text("Lot Size به د Deriv د قرارداد د مشخصاتو له تایید پرته نه ټاکل کېږي.",
                                color = Color(0xFFFFD580), fontSize = 12.sp)
                        }
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A314A))) {
                        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.NotificationsActive, null, tint = Gold)
                                Spacer(Modifier.width(8.dp))
                                Text("د خبرتیاوو تنظیم", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Text("د خبرتیاوو د فعالولو غوښتنه", color = Color(0xFFCBD5E1))
                            Switch(checked = notifications, onCheckedChange = { notifications = it })
                            Text(
                                if (notifications) "خبرتیاوې فعالې شوې دي."
                                else "د خبرتیاوو د فعالولو لپاره سویچ چالان کړئ.",
                                color = Muted, fontSize = 12.sp
                            )
                        }
                    }
                    Text("د تحلیل وخت: M15 • H1", color = Color(0xFFCBD5E1))
                    Text("نسخه 0.3 • له سرور سره وصل", color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun SignalCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF1A314A)),
        shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, color = Muted, fontSize = 12.sp)
            Text(value, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }
}
