SHARAF GOLD SIGNAL PRO - نسخه 0.2 (TradingView Chart Demo)

دا د Android Studio لپاره د Android اپلیکیشن سرچینه ده، APK نه دی.

نوې برخه:
- د اپلیکیشن دننه TradingView ویب چارټ
- د چارټ سمبول OANDA:XAUUSD
- M15 وخت‌چوکاټ
- پښتو ډشبورډ او د سیګنال معلوماتو تش ځایونه

مهم محدودیتونه:
- دا چارټ د OANDA سرچینه کاروي، نه د Deriv د حساب تایید شوی نرخ.
- چارټ یوازې د لیدلو لپاره دی؛ دا د BUY/SELL سیګنال نه جوړوي.
- د Deriv ژوندی API، ازمویل شوی سیګنال انجن، Cloud سرور او Push خبرتیاوې لا نه دي وصل شوي.
- د خبرتیا سویچ یوازې د پروټوټایپ UI دی.
- د دې ZIP څخه APK جوړولو لپاره Android Studio او کمپیوټر ته اړتیا ده.

د جوړولو لار:
1. Android Studio نصب کړئ.
2. دا ZIP Extract کړئ.
3. فولډر په Android Studio کې Open کړئ.
4. Gradle Sync ته انتظار وکړئ.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) وټاکئ.

امنیت:
د Deriv پاسورډ یا API Token په اپ کې مه داخلوئ او له چا سره یې مه شریکوئ.
